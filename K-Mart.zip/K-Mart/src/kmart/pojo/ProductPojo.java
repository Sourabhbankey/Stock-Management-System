/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kmart.pojo;

import java.util.Objects;

/**
 *
 * @author dell
 */
public class ProductPojo {

    @Override
    public String toString() {
        return "ProductPojo{" + "ProductId=" + ProductId + ", ProductName=" + ProductName + ", ProductCompany=" + ProductCompany + ", ProductPrice=" + ProductPrice + ", OurPrice=" + OurPrice + ", tax=" + tax + ", quantity=" + quantity + ", total=" + total + ", UserID=" + UserID + '}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 29 * hash + Objects.hashCode(this.ProductId);
        hash = 29 * hash + Objects.hashCode(this.ProductName);
        hash = 29 * hash + Objects.hashCode(this.ProductCompany);
        hash = 29 * hash + (int) (Double.doubleToLongBits(this.ProductPrice) ^ (Double.doubleToLongBits(this.ProductPrice) >>> 32));
        hash = 29 * hash + (int) (Double.doubleToLongBits(this.OurPrice) ^ (Double.doubleToLongBits(this.OurPrice) >>> 32));
        hash = 29 * hash + this.tax;
        hash = 29 * hash + this.quantity;
        hash = 29 * hash + (int) (Double.doubleToLongBits(this.total) ^ (Double.doubleToLongBits(this.total) >>> 32));
        hash = 29 * hash + Objects.hashCode(this.UserID);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ProductPojo other = (ProductPojo) obj;
        if (Double.doubleToLongBits(this.ProductPrice) != Double.doubleToLongBits(other.ProductPrice)) {
            return false;
        }
        if (Double.doubleToLongBits(this.OurPrice) != Double.doubleToLongBits(other.OurPrice)) {
            return false;
        }
        if (this.tax != other.tax) {
            return false;
        }
        if (this.quantity != other.quantity) {
            return false;
        }
        if (Double.doubleToLongBits(this.total) != Double.doubleToLongBits(other.total)) {
            return false;
        }
        if (!Objects.equals(this.ProductId, other.ProductId)) {
            return false;
        }
        if (!Objects.equals(this.ProductName, other.ProductName)) {
            return false;
        }
        if (!Objects.equals(this.ProductCompany, other.ProductCompany)) {
            return false;
        }
        if (!Objects.equals(this.UserID, other.UserID)) {
            return false;
        }
        return true;
    }

    public String getUserID() {
        return UserID;
    }

    public void setUserID(String UserID) {
        this.UserID = UserID;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public ProductPojo(String ProductId, String ProductName, String ProductCompany, double ProductPrice, double OurPrice, int tax, int quantity, double total, String UserID) {
        this.ProductId = ProductId;
        this.ProductName = ProductName;
        this.ProductCompany = ProductCompany;
        this.ProductPrice = ProductPrice;
        this.OurPrice = OurPrice;
        this.tax = tax;
        this.quantity = quantity;
        this.total=total;
        this.UserID=UserID;
    }
   public ProductPojo()
   {
       
   }
    public String getProductId() {
        return ProductId;
    }

    public void setProductId(String ProductId) {
        this.ProductId = ProductId;
    }

    public String getProductName() {
        return ProductName;
    }

    public void setProductName(String ProductName) {
        this.ProductName = ProductName;
    }

    public String getProductCompany() {
        return ProductCompany;
    }

    public void setProductCompany(String ProductCompany) {
        this.ProductCompany = ProductCompany;
    }

    public double getProductPrice() {
        return ProductPrice;
    }

    public void setProductPrice(double ProductPrice) {
        this.ProductPrice = ProductPrice;
    }

    public double getOurPrice() {
        return OurPrice;
    }

    public void setOurPrice(double OurPrice) {
        this.OurPrice = OurPrice;
    }

    public int getTax() {
        return tax;
    }

    public void setTax(int tax) {
        this.tax = tax;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    private String ProductId;
    private String ProductName;
    private String ProductCompany;
    private double ProductPrice;
    private double OurPrice;
    private int tax;
    private int quantity;
    private double total;
    private String UserID;
    
}
