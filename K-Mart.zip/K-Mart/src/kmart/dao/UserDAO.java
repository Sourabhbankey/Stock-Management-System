/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kmart.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import kmart.dbutil.DBConnection;
import kmart.pojo.UserPojo;
import kmart.pojo.UserProfile;

/**
 *
 * @author dell
 */
public class UserDAO {
    public static boolean validateUser(UserPojo user) throws SQLException
    {
        Connection conn=DBConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement("Select * from users where userid=? and password=? and usertype=?");
        ps.setString(1,user.getUserid());
        ps.setString(2,user.getPassword());
        ps.setString(3,user.getUsertype());
        ResultSet rs=ps.executeQuery();
        
        if(rs.next())
        {
           String s=rs.getString(5);
           UserProfile.setUsername(s);
             return true;
        }
        return false;
    }
    public static boolean isUserPresent(String empid)throws SQLException
    {
         Connection conn=DBConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement("Select 1 from users where empid=?");
        ps.setString(1,empid);
        ResultSet rs=ps.executeQuery();
        return rs.next();
    }
    public static List<String> getAllUsers()throws SQLException
    {
        Connection conn=DBConnection.getConnection();
         Statement st=conn.createStatement();
         ResultSet rs;
         ArrayList<String> al=new ArrayList<>();
         rs=st.executeQuery("select userid from users where usertype='Receptionist'");
         while(rs.next())
         {
             String id=rs.getString(1);
             al.add(id);
         }
         return al;
         
    }
}
