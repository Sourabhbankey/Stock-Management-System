/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kmart.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import kmart.dbutil.DBConnection;
import kmart.pojo.ReceptionistPojo;
import kmart.pojo.UserPojo;

/**
 *
 * @author dell
 */
public class ReceptionistDAO {
    public static Map<String , String> getNonRegisteredReceptionists()throws SQLException
    {
        Connection conn=DBConnection.getConnection();
        Statement st=conn.createStatement();
        ResultSet rs=st.executeQuery("Select empid,empname from employees where job='Receptionist' and empid not in (Select empid from users where usertype='Receptionist')");
         HashMap<String,String> receptionistList=new HashMap<>();
         while(rs.next())
         {
             
             String id=rs.getString(1);
             String name=rs.getString(2);
             
             receptionistList.put(id,name);
         }
         return receptionistList;
    }
    public static boolean UpdateReceptionist(String userid,String pwd)throws SQLException
    {
         Connection conn=DBConnection.getConnection();
          PreparedStatement ps=conn.prepareStatement("Update users set password=? where userid=?");
         ps.setString(1, pwd);
         ps.setString(2, userid);
         int result=ps.executeUpdate();
         return result==1;
    }
     
    public static Map<String , String> getAllReceptionistID()throws SQLException
    {
        Connection conn=DBConnection.getConnection();
         Statement st=conn.createStatement();
         ResultSet rs=st.executeQuery("Select userid,username from users where usertype='Receptionist' order by userid");
        HashMap<String,String> receptionistList=new HashMap<>();
        while(rs.next())
        {
            String id=rs.getString(1);
            String name=rs.getString(2);
            receptionistList.put(id,name);
        }
        return receptionistList;
    }
    public static  String getReceptionistNameByID(String id)throws SQLException
    {
        Connection conn=DBConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement("select username from users where userid=?");
        ps.setString(1,id);
       ResultSet rs= ps.executeQuery();
        String name=null;
       if(rs.next())
       {
            name=rs.getString(1);
       }
       return name;
    }
    public static boolean addReceptionist(UserPojo user)throws SQLException
    {
        Connection conn=DBConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement("Insert into users values(?,?,?,?,?)");
        ps.setString(1,user.getUserid());
        ps.setString(2, user.getEmpid());
        ps.setString(3, user.getPassword());
        ps.setString(4,user.getUsertype());
        ps.setString(5,user.getUsername());
        int result=ps.executeUpdate();
        return result==1;
    }
    public static List<ReceptionistPojo> getAllReceptionistDetails()throws SQLException
    {
        Connection conn=DBConnection.getConnection();
        Statement st=conn.createStatement();
        ResultSet rs=st.executeQuery("Select Users.empid , empname, userid,job,salary from users,employees where usertype='Receptionist' and users.empid=employees.empid");
        ArrayList<ReceptionistPojo> al=new ArrayList<>();
        while(rs.next())
        {
            ReceptionistPojo recep=new ReceptionistPojo();
            recep.setEmpid(rs.getString(1));
            recep.setEmpname(rs.getString(2));
            recep.setUserid(rs.getString(3));
            recep.setJob(rs.getString(4));
            recep.setSalary(rs.getDouble(5));
            al.add(recep);
        }
        return al;
    }
    public static UserPojo getReceptionistDetailsByID(String id)throws SQLException
    {
        Connection conn=DBConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement("Select * from users where userid=?");
        ps.setString(1,id);
        ResultSet rs=ps.executeQuery();
        UserPojo recep=new UserPojo();
           rs.next();
            recep.setUserid(rs.getString(1));
            recep.setEmpid(rs.getString(2));
            recep.setPassword(rs.getString(3));
            recep.setUsertype(rs.getString(4));
            recep.setUsername(rs.getString(5));
        return recep;
    }
    public static boolean DeleteReceptionist(String id)throws SQLException
    {
        Connection conn=DBConnection.getConnection();
         PreparedStatement ps=conn.prepareStatement("Delete from users where userid=?");
         ps.setString(1,id);
         int x=ps.executeUpdate();
         return x==1;
    }
    public static List<String> getAllReceptionistUsersID() throws SQLException
    {
        Connection conn=DBConnection.getConnection();
        Statement st=conn.createStatement();
        ResultSet rs=st.executeQuery("Select userid from users where usertype='Receptionist' order by userid");
        List<String> receptionistList=new ArrayList<>();
        while(rs.next())
        {
            String id=rs.getString(1);
            receptionistList.add(id);
        }
        return receptionistList;
    }
}
