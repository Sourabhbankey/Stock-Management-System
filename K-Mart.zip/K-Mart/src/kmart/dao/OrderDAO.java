/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kmart.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import kmart.dbutil.DBConnection;
import kmart.pojo.ProductPojo;
import kmart.pojo.UserProfile;

/**
 *
 * @author dell
 */
public class OrderDAO {
   public static String getNextOrderID()throws SQLException
    {
        Connection conn=DBConnection.getConnection();
         Statement st=conn.createStatement();
         ResultSet rs;
        rs = st.executeQuery("select max(order_id) as \" Maximum order_id  \" from orders");
          rs.next();
        String orid=rs.getString(1);
        if(orid==null)
            return "O-101";
        int orno=Integer.parseInt(orid.substring(2));
         orno++;
        return "O-"+orno;
    }
   public static boolean addOrder(ArrayList<ProductPojo> al, String ordID)throws SQLException
   {
       Connection conn=DBConnection.getConnection();
       PreparedStatement ps=conn.prepareStatement("Insert into orders values(?,?,?,?)");
       int count=0;
       for(ProductPojo p:al)
       {
          ps.setString(1, ordID);
          ps.setString(2,p.getProductId());
          ps.setInt(3,p.getQuantity());
          ps.setString(4, UserProfile.getUserid());
          count=count+ps.executeUpdate();
       }
       return count==al.size();
   }        
   public static HashSet<String> getAllOrderID() throws SQLException
   {
       Connection conn=DBConnection.getConnection();
       PreparedStatement ps=conn.prepareStatement("select Order_id from orders where userid=?");
       ResultSet rs;
       ps.setString(1,UserProfile.getUserid());
        rs=ps.executeQuery();
         HashSet<String> al=new HashSet<>();
        while(rs.next())
        {
            String id=rs.getString(1);
            al.add(id);
        }
        return al;
   }
    public static HashSet<String> getAllOrderIDByUserID(String u) throws SQLException
   {
       Connection conn=DBConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement("select Order_id from orders where Userid=?");
        ps.setString(1, u);
        ResultSet rs;
        rs=ps.executeQuery();
        
         HashSet<String> al=new HashSet<>();
        while(rs.next())
        {
            String id=rs.getString(1);
            al.add(id);
        }
        return al;
   }
   public static List<ProductPojo> getProductByOrderID(String oID) throws SQLException
   {
       Connection conn=DBConnection.getConnection();
       PreparedStatement ps=conn.prepareStatement("select * from orders where order_id=?");
        ResultSet rs;
        ps.setString(1, oID);
        rs=ps.executeQuery();
        ArrayList<ProductPojo> al=new ArrayList<>();
        while(rs.next())
        {
            ProductPojo p=new ProductPojo();
            p.setProductId(rs.getString(2));
            p.setQuantity(rs.getInt(3));
            p.setUserID(rs.getString(4));
            al.add(p);
        }
        return al;
   }
}

