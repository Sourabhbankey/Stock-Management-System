/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vidKush;

/**
 *
 * @author dell
 */
 import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import org.json.JSONObject;
public class demo1 {
 

 
    public static void main(String[] args) throws Exception {
       try {
            URL url = new URL("https://parseapi.back4app.com/classes/Continentscountriescities_Country?count=1&limit=400&order=name,phone&keys=name,phone");
            HttpURLConnection urlConnection = (HttpURLConnection)url.openConnection();
            urlConnection.setRequestProperty("X-Parse-Application-Id", "g1veNwd6PB6I4d0iAQQDn5u6NfSxEI1nPfSCpPuU"); // This is your app's application id
            urlConnection.setRequestProperty("X-Parse-REST-API-Key", "S7qcCM1mOvr83qM3uqlQrokthcobyDYIxZkOQmF8"); // This is your app's REST API key
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                }
                JSONObject data = new JSONObject(stringBuilder.toString()); // Here you have the data that you need
                System.out.println(data.toString(2));
            } finally {
                urlConnection.disconnect();
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.toString());
        }
    
    }
}  

